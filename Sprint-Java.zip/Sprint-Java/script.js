console.log("JavaScript is linked correctly!");

fetch('data.json')
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        console.log(data); // Log the entire JSON data to the console
        displayData(data); // Call the display function
    })
    .catch(error => {
        console.error('There has been a problem with your fetch operation:', error);
    });


     function displayData(data) {
        data.forEach(record => {
            console.log(`Name: ${record.name}`); // Display name in the console
        });
    }
    
    function getAgeDescription(record) {
        return `${record.name} is ${record.age} years old.`;
    }
    
    function getCityDescription(record) {
        return `${record.name} lives in ${record.city}.`;
    }
    
    function getIdDescription(record) {
        return `${record.name}'s ID is ${record.id}.`;
    }

function displayData(data) {
    const dataDiv = document.getElementById('data');
    data.forEach(record => {
        console.log(`Name: ${record.name}`); // Display name in the console
        const ageDescription = getAgeDescription(record);
        const cityDescription = getCityDescription(record);
        const idDescription = getIdDescription(record);
            
        // Append descriptions to the dataDiv
        dataDiv.innerHTML += `<p>${ageDescription}</p>`;
        dataDiv.innerHTML += `<p>${cityDescription}</p>`;
        dataDiv.innerHTML += `<p>${idDescription}</p>`;
    });
}
    